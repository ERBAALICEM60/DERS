package com.example.sinavhazirlik;

public class DortIslem {
    public int s1;
    public int s2;

    public DortIslem(int s1, int s2) {
        this.s1 = s1;
        this.s2 = s2;
    }

    public int topla(){return s1+s2;}
    public int cikar(){return s1-s2;}
    public int carp(){return s1*s2;}
    public int bol(){return s1/s2;}
}
