package com.example.sinavhazirlik;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    int s1,s2,sonuc;
    EditText eTextSayiBir,eTextSayiIki;
    TextView txtSonuc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        eTextSayiBir=findViewById(R.id.eTextSayiBir);
        eTextSayiIki=findViewById(R.id.eTextSayiIki);
        txtSonuc=findViewById(R.id.txtSonuc);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void sayilariOku(){
        s1=Integer.parseInt(eTextSayiBir.getText().toString());
        s2=Integer.parseInt(eTextSayiIki.getText().toString());

     }

     public void sonucuYazdir(){
        txtSonuc.setText("İlk Sayı:"+Integer.toString(s1)+"\nİkinci Sayı:"+Integer.toString(s2)+"\nSonuc:"+Integer.toString(sonuc));
       }

    public void btnTopla_Click(View view){
        sayilariOku();
        DortIslem islem=new DortIslem(s1,s2);
        sonuc=islem.topla();
        sonucuYazdir();
    }

    public void btnCikar_Click(View view){
        sayilariOku();
        DortIslem islem=new DortIslem(s1,s2);
        sonuc=islem.cikar();
        sonucuYazdir();
    }

    public void btnCarp_Click(View view){
        sayilariOku();
        DortIslem islem=new DortIslem(s1,s2);
        sonuc=islem.carp();
        sonucuYazdir();
    }

    public void btnBol_Click(View view){
        sayilariOku();
        DortIslem islem=new DortIslem(s1,s2);
        sonuc=islem.bol();
        sonucuYazdir();
    }


}